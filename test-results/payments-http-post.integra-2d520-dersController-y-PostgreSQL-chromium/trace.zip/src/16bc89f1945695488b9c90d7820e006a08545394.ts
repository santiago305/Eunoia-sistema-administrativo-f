import { expect, test } from "@playwright/test";

test.skip(process.env.PAYMENTS_HTTP_INTEGRATION !== "1", "Requiere la red Docker financiera efímera.");

test("contabiliza desde Ingresos: navegador → API HTTP → PostgreSQL real", async ({ page, request }) => {
  const apiBase = process.env.VITE_API_BASE_URL?.replace(/\/api\/?$/, "") ?? "http://payments-api:3200";
  const prepared = await request.post(`${apiBase}/prepare-post`).then((response) => response.json());
  expect(prepared).toMatchObject({ ready: true, incomeId: "60000000-0000-4000-8000-000000000001" });
  const before = await request.get(`${apiBase}/test-state`).then((response) => response.json());
  expect(before).toMatchObject({ status: "PENDING_CONFIRMATION", version: 1, movements: 0, allocations: 0 });

  await page.goto("/e2e/income-page-harness.html");
  const row = page.getByRole("row").filter({ hasText: "PED-HTTP-001" });
  await expect(row).toContainText("Por confirmar");
  await row.getByRole("button", { name: "Acciones del ingreso PED-HTTP-001" }).click();
  await page.getByText("Contabilizar", { exact: true }).click();

  const dialog = page.getByRole("dialog", { name: "Contabilizar ingreso" });
  await expect(dialog).toContainText("45.67");
  await expect(dialog.getByRole("button", { name: "Contabilizar" })).toBeEnabled();
  await dialog.getByRole("button", { name: "Contabilizar" }).click();
  await expect(row).toContainText("Contabilizado");

  const after = await request.get(`${apiBase}/test-state`).then((response) => response.json());
  expect(after).toMatchObject({ status: "POSTED", version: 2, movements: 1, allocations: 1 });
});

test("recupera un lote contabilizado cuando Chromium pierde la respuesta HTTP", async ({ page, request }) => {
  const apiBase = process.env.VITE_API_BASE_URL?.replace(/\/api\/?$/, "") ?? "http://payments-api:3200";
  const prepared = await request.post(`${apiBase}/prepare-batch`).then((response) => response.json());
  expect(prepared).toMatchObject({ ready: true, incomeIds: expect.arrayContaining([
    "60000000-0000-4000-8000-000000000001",
    "60000000-0000-4000-8000-000000000003",
  ]) });
  const before = await request.get(`${apiBase}/test-batch-state`).then((response) => response.json());
  expect(before).toMatchObject({ movements: 0, allocations: 0, outboxEvents: 0, auditEvents: 0, completedBatches: 0 });
  expect(before.payments).toEqual(expect.arrayContaining([
    expect.objectContaining({ status: "PENDING_CONFIRMATION", version: 1 }),
    expect.objectContaining({ status: "PENDING_CONFIRMATION", version: 1 }),
  ]));

  let batchPostCount = 0;
  let idempotencyKey = "";
  await page.route("**/income/post-batch", async (route) => {
    batchPostCount += 1;
    const body = route.request().postDataJSON() as { idempotencyKey: string };
    idempotencyKey = body.idempotencyKey;
    const committedResponse = await route.fetch();
    expect(committedResponse.status()).toBe(201);
    const committedBody = await committedResponse.json();
    expect(committedBody).toMatchObject({ type: "success", count: 2, batchId: idempotencyKey });
    // The API has committed; abort only the browser-facing response to simulate a lost connection.
    await route.abort("failed");
  });

  await page.goto("/e2e/income-page-harness.html?permissions=sale_orders.payments.post_bulk,income.view_all");
  const firstRow = page.getByRole("row").filter({ hasText: "PED-HTTP-001" });
  const secondRow = page.getByRole("row").filter({ hasText: "PED-HTTP-002" });
  await expect(firstRow).toContainText("Por confirmar");
  await expect(secondRow).toContainText("Por confirmar");
  await firstRow.getByRole("button").first().click();
  await secondRow.getByRole("button").first().click();
  await page.getByRole("button", { name: "Contabilizar seleccionados (2)" }).click();
  const confirmation = page.getByRole("dialog", { name: "Contabilizar ingresos" });
  await expect(confirmation).toBeVisible();
  const recoveredResultPromise = page.waitForResponse((response) => response.url().includes("/income/bulk-operations/"));
  await confirmation.getByRole("button", { name: "Contabilizar", exact: true }).click();
  const recoveredResult = await recoveredResultPromise;
  expect(recoveredResult.status()).toBe(200);
  expect(await recoveredResult.json()).toMatchObject({ type: "success", batchId: idempotencyKey, count: 2 });
  await expect(firstRow).toContainText("Contabilizado");
  await expect(secondRow).toContainText("Contabilizado");
  expect(batchPostCount).toBe(1);

  const after = await request.get(`${apiBase}/test-batch-state`).then((response) => response.json());
  expect(after).toMatchObject({ movements: 2, allocations: 2, outboxEvents: 2, auditEvents: 2, completedBatches: 1 });
  expect(after.payments).toEqual(expect.arrayContaining([
    expect.objectContaining({ status: "POSTED", version: 2 }),
    expect.objectContaining({ status: "POSTED", version: 2 }),
  ]));
});

test("edita desde Ingresos hasta el IncomeController real y conserva el pago ante un número duplicado", async ({ page, request }) => {
  const apiBase = process.env.VITE_API_BASE_URL?.replace(/\/api\/?$/, "") ?? "http://payments-api:3200";
  const prepared = await request.post(`${apiBase}/prepare-edit-duplicate`).then((response) => response.json());
  expect(prepared).toMatchObject({ ready: true, incomeId: "60000000-0000-4000-8000-000000000003" });

  const before = await request.get(`${apiBase}/test-edit-state`).then((response) => response.json());
  expect(before).toMatchObject({ status: "PENDING_CONFIRMATION", version: 1, operation_number: null, note: null, edits: 0, movements: 0, outboxEvents: 0 });

  await page.goto("/e2e/income-page-harness.html?permissions=sale_orders.payments.update_pending,income.view_all");
  const row = page.getByRole("row").filter({ hasText: "PED-HTTP-001" });
  await expect(row).toContainText("Por confirmar");
  await row.getByRole("button", { name: "Acciones del ingreso PED-HTTP-001" }).click();
  await page.getByText("Editar ingreso", { exact: true }).click();

  const dialog = page.getByRole("dialog", { name: "Modificar pago" });
  await dialog.getByLabel("Número de operación").fill("OP-HTTP-DUPLICATE");
  await dialog.getByRole("button", { name: "Guardar cambios" }).click();
  await expect(dialog.getByRole("alert")).toHaveText("Ese número de operación ya está registrado.");
  await expect(dialog).toBeVisible();
  await expect(row).toContainText("Por confirmar");

  const after = await request.get(`${apiBase}/test-edit-state`).then((response) => response.json());
  expect(after).toMatchObject({ status: "PENDING_CONFIRMATION", version: 1, operation_number: null, note: null, edits: 0, movements: 0, outboxEvents: 0 });
});

test("guarda una edición pendiente desde Chromium hasta IncomeController y PostgreSQL", async ({ page, request }) => {
  const apiBase = process.env.VITE_API_BASE_URL?.replace(/\/api\/?$/, "") ?? "http://payments-api:3200";
  const prepared = await request.post(`${apiBase}/prepare-edit-duplicate`).then((response) => response.json());
  expect(prepared).toMatchObject({ ready: true, incomeId: "60000000-0000-4000-8000-000000000003" });

  await page.goto("/e2e/income-page-harness.html?permissions=sale_orders.payments.update_pending,income.view_all");
  const row = page.getByRole("row").filter({ hasText: "PED-HTTP-001" });
  await expect(row).toContainText("Por confirmar");
  await row.getByRole("button", { name: "Acciones del ingreso PED-HTTP-001" }).click();
  await page.getByText("Editar ingreso", { exact: true }).click();

  const dialog = page.getByRole("dialog", { name: "Modificar pago" });
  await dialog.getByLabel("Número de operación").fill("OP-HTTP-EDIT-SUCCESS");
  await dialog.getByLabel("Descripción").fill("Actualizado desde Chromium");
  await dialog.getByRole("button", { name: "Guardar cambios" }).click();
  await expect(dialog).toBeHidden();

  const after = await request.get(`${apiBase}/test-edit-state`).then((response) => response.json());
  expect(after).toMatchObject({
    status: "PENDING_CONFIRMATION",
    version: 2,
    operation_number: "OP-HTTP-EDIT-SUCCESS",
    note: "Actualizado desde Chromium",
    edits: 1,
    movements: 0,
    outboxEvents: 1,
  });
});

test("corrige un ingreso contabilizado desde Chromium y verifica reversa y reemplazo en PostgreSQL", async ({ page, request }) => {
  const apiBase = process.env.VITE_API_BASE_URL?.replace(/\/api\/?$/, "") ?? "http://payments-api:3200";
  const prepared = await request.post(`${apiBase}/prepare-correct`).then((response) => response.json());
  expect(prepared).toMatchObject({ ready: true, incomeId: "60000000-0000-4000-8000-000000000001" });

  await page.goto("/e2e/income-page-harness.html?permissions=sale_orders.payments.correct_posted,income.view_all");
  const row = page.getByRole("row").filter({ hasText: "PED-HTTP-001" });
  await expect(row).toContainText("Contabilizado");
  await row.getByRole("button", { name: "Acciones del ingreso PED-HTTP-001" }).click();
  await page.getByText("Corregir ingreso contabilizado", { exact: true }).click();

  const dialog = page.getByRole("dialog", { name: "Corregir ingreso contabilizado" });
  await dialog.getByLabel("Número de operación").fill("OP-HTTP-CORRECTED");
  await dialog.getByLabel("Descripción").fill("Reemplazo confirmado desde Chromium");
  await dialog.getByLabel("Motivo de la corrección").fill("Corrección integral E2E");
  const correctionResponsePromise = page.waitForResponse((response) => response.url().includes(`/income/${prepared.incomeId}/correct`));
  await dialog.getByRole("button", { name: "Corregir ingreso" }).click();
  const correctionResponse = await correctionResponsePromise;
  const correctionBody = await correctionResponse.json();
  expect(correctionResponse.status(), JSON.stringify(correctionBody)).toBe(201);
  await expect(dialog).toBeHidden();

  const after = await request.get(`${apiBase}/test-correction-state`).then((response) => response.json());
  expect(after.source).toMatchObject({ status: "REVERSED", version: 3, operation_number: "OP-HTTP-CORRECTION-ORIGINAL" });
  expect(after.replacement).toMatchObject({ status: "POSTED", version: 1, operation_number: "OP-HTTP-CORRECTED" });
  expect(after.movements).toHaveLength(3);
  expect(after.movements).toEqual(expect.arrayContaining([
    expect.objectContaining({ paymentId: prepared.incomeId, type: "INCOME", count: 1, amount: "45.67" }),
    expect.objectContaining({ paymentId: prepared.incomeId, type: "REVERSAL", count: 1, amount: "-45.67" }),
    expect.objectContaining({ paymentId: after.replacement.id, type: "INCOME", count: 1, amount: "45.67" }),
  ]));
  expect(after.allocations).toBe(3);
  expect(after.outboxEvents).toBe(2);
  expect(after.audit.map((item: { action_execution: string }) => item.action_execution)).toEqual([
    "payment_corrected_in",
    "payment_corrected_out",
  ]);
});

test("resuelve pagos al cancelar desde Chromium hasta SaleOrdersController y PostgreSQL", async ({ page, request }) => {
  test.setTimeout(90_000);
  page.setDefaultNavigationTimeout(60_000);
  const apiBase = process.env.VITE_API_BASE_URL?.replace(/\/api\/?$/, "") ?? "http://payments-api:3200";
  const prepared = await request.post(`${apiBase}/prepare-cancel-order`).then((response) => response.json());
  expect(prepared).toMatchObject({ ready: true, orderId: "50000000-0000-4000-8000-000000000001" });
  const before = await request.get(`${apiBase}/test-cancel-order-state`).then((response) => response.json());
  expect(before).toMatchObject({ currentStateId: null, movements: [expect.objectContaining({ type: "INCOME", amount: "45.67" })], auditEvents: 0, outboxEvents: 0, completedOperations: 0 });
  expect(before.payments).toEqual(expect.arrayContaining([
    expect.objectContaining({ id: "60000000-0000-4000-8000-000000000001", status: "POSTED", version: 2 }),
    expect.objectContaining({ id: "60000000-0000-4000-8000-000000000002", status: "PENDING_CONFIRMATION", version: 1 }),
  ]));

  await page.goto(`/e2e/cancellation-resolution-harness.html?order=${prepared.orderId}`, { waitUntil: "domcontentloaded" });
  const pending = page.locator("section").filter({ hasText: "Ingreso por confirmar" });
  const posted = page.locator("section").filter({ hasText: "Ingreso contabilizado" });
  await expect(pending).toContainText("20.00");
  await expect(posted).toContainText("45.67");
  await pending.getByLabel(/Motivo/).fill("Cancelar pendiente por cierre del pedido");
  await posted.getByLabel(/Motivo/).fill("Conservar contabilizado como saldo del cliente");
  await page.getByLabel("Confirmo las resoluciones indicadas y la cancelación definitiva del pedido.").check();
  const cancelResponsePromise = page.waitForResponse((response) => response.url().includes(`/sale-orders/${prepared.orderId}/cancel`));
  await page.getByRole("button", { name: "Resolver y cancelar pedido" }).click();
  const cancelResponse = await cancelResponsePromise;
  expect(cancelResponse.status()).toBe(200);
  expect(await cancelResponse.json()).toMatchObject({ saleOrderId: prepared.orderId, currentStateId: "90000000-0000-4000-8000-000000000002" });
  await expect(page.getByTestId("cancellation-result")).toHaveText("completed");

  const after = await request.get(`${apiBase}/test-cancel-order-state`).then((response) => response.json());
  expect(after.currentStateId).toBe("90000000-0000-4000-8000-000000000002");
  expect(after.payments).toEqual(expect.arrayContaining([
    expect.objectContaining({ id: "60000000-0000-4000-8000-000000000001", status: "POSTED", version: 2 }),
    expect.objectContaining({ id: "60000000-0000-4000-8000-000000000002", status: "CANCELLED", version: 2 }),
  ]));
  expect(after.movements).toEqual([expect.objectContaining({ type: "INCOME", amount: "45.67" })]);
  expect(after.allocations).toEqual(expect.arrayContaining([
    expect.objectContaining({ amount: "45.67" }),
    expect.objectContaining({ amount: "-45.67" }),
  ]));
  expect(after.credits).toEqual([expect.objectContaining({ type: "RELEASE", amount: "45.67" })]);
  expect(after).toMatchObject({ auditEvents: 2, outboxEvents: 2, completedOperations: 1 });
});
